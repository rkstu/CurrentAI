# Tests initialization

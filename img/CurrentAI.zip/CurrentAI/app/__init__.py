# from flask import Flask
# from .config import Config
# # from .routes import api_bp

# # def create_app():
# #     app = Flask(__name__)
# #     app.config.from_object(Config)

# #     # Register blueprints
# #     # app.register_blueprint(api_bp)

# #     # @app.route('/')
# #     # def index():
# #     #     return app.send_static_file('index.html')

# #     return app

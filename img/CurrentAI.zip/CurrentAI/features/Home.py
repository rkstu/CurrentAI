import streamlit as st

def main():
    st.title("Welcome to the ChatGPT-like Application")
    st.write("Navigate using the sidebar to sign up, log in, or start chatting.")

if __name__ == "__main__":
    main()
